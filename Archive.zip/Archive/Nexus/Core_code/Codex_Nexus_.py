import tkinter as tk
from tkinter import filedialog
import os

class CoreManager:
    """
    Manages the core codebase, caches it in memory, and integrates new modules.
    """

    def __init__(self):
        # Initialize core code as an empty string and create Nexus directory structure
        self.core_code = ""
        self.nexus_dir = "Nexus"
        self.core_code_dir = os.path.join(self.nexus_dir, "Core_code")
        self.module_updates_dir = os.path.join(self.nexus_dir, "Module_updates")
        self.history_dir = os.path.join(self.nexus_dir, "History")

        # Create the Nexus directory structure if it doesn't exist
        self.create_folders()

    def create_folders(self):
        # Ensure the Nexus folder and its subfolders exist
        if not os.path.exists(self.nexus_dir):
            os.makedirs(self.nexus_dir)
            print(f"Created Nexus directory at: {os.path.abspath(self.nexus_dir)}")
        if not os.path.exists(self.core_code_dir):
            os.makedirs(self.core_code_dir)
            print(f"Created Core_code directory at: {os.path.abspath(self.core_code_dir)}")
        if not os.path.exists(self.module_updates_dir):
            os.makedirs(self.module_updates_dir)
            print(f"Created Module_updates directory at: {os.path.abspath(self.module_updates_dir)}")
        if not os.path.exists(self.history_dir):
            os.makedirs(self.history_dir)
            print(f"Created History directory at: {os.path.abspath(self.history_dir)}")

    def save_core_code(self, code, filename, is_module=False):
        """
        Saves the given code as the core code or module code to appropriate folders.
        :param code: The code to save
        :param filename: Name of the file to save the code
        :param is_module: Boolean flag indicating if the code is a module (default: False)
        """
        self.core_code = code

        if is_module:
            save_path = os.path.join(self.module_updates_dir, filename)
        else:
            save_path = os.path.join(self.core_code_dir, filename)

        with open(save_path, 'w') as file:
            file.write(code)
        print(f"Code saved as {filename} in {'Module_updates' if is_module else 'Core_code'} folder.")

        # Save a history version of the core code
        self.save_history(filename, code)

    def load_core_code(self, filename):
        """
        Loads core code from a Python file.
        :param filename: Name of the Python file to load the core code from
        :return: Loaded code
        """
        try:
            file_path = os.path.join(self.core_code_dir, filename)
            with open(file_path, 'r') as file:
                self.core_code = file.read()
            return self.core_code
        except FileNotFoundError:
            print(f"File {filename}.py not found in Core_code directory.")
            return None

    def save_history(self, filename, code):
        """
        Saves a copy of the code as a historical version.
        :param filename: The name of the file being saved
        :param code: The code to save
        """
        history_filename = f"{filename}_{len(os.listdir(self.history_dir)) + 1}.py"
        history_path = os.path.join(self.history_dir, history_filename)

        with open(history_path, 'w') as file:
            file.write(code)
        print(f"History saved as {history_filename}.")

    def get_cache(self):
        """
        Returns a list of saved Python scripts in the core_code and module_updates directories.
        :return: List of filenames in the cache
        """
        core_files = [f for f in os.listdir(self.core_code_dir) if f.endswith('.py')]
        module_files = [f for f in os.listdir(self.module_updates_dir) if f.endswith('.py')]
        return core_files + module_files

class Diagnostics:
    """
    Handles error tracking, severity categorization, and diagnostics.
    """

    def scan_code(self, code):
        """
        Scans the code for empty lines and other potential issues.
        :param code: The code to analyze
        :return: Diagnostic report
        """
        lines = code.split("\n")
        report = []
        previous_empty = False  # Tracks consecutive empty lines

        for i, line in enumerate(lines, start=1):
            if not line.strip():  # Empty line detected
                if previous_empty:  # Flag consecutive empty lines
                    report.append(f"Line {i}: Redundant empty line.")
                previous_empty = True
            else:
                previous_empty = False

        if report:
            return "Diagnostics Report:\n" + "\n".join(report)
        else:
            return "Diagnostics Report:\nNo issues found. Code looks clean!"


class Integrator:
    """
    Integrates new modules into the core code with error detection and conflict resolution.
    """

    def __init__(self, core_manager):
        self.core_manager = core_manager

    def integrate_module(self, new_module, filename):
        """
        Integrates a new module into the core code.
        :param new_module: The new module to integrate
        :param filename: The name of the module to save
        :return: The updated core code with the new module
        """
        updated_code = self.core_manager.integrate_module(new_module, filename)
        return updated_code


class CodexNexusApp:
    """
    GUI application for Codex Nexus.
    """

    def __init__(self):
        self.diagnostics = Diagnostics()
        self.core_manager = CoreManager()
        self.integrator = Integrator(self.core_manager)

    def initialize_ui(self):
        """
        Initializes the User Interface with Tkinter.
        """
        self.root = tk.Tk()
        self.root.title("Codex Nexus Scanner")
        self.root.geometry("800x600")

        # Create a PanedWindow to split the UI into two sections
        self.paned_window = tk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        self.paned_window.pack(fill=tk.BOTH, expand=True)

        # Left Pane for displaying core code (editable)
        self.left_frame = tk.Frame(self.paned_window, width=300)
        self.left_frame.pack(fill=tk.BOTH, expand=True)

        self.core_code_display = tk.Text(self.left_frame, wrap="word", height=30, width=40, bg="lightgrey")
        self.core_code_display.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Right Pane for module data integration
        self.right_frame = tk.Frame(self.paned_window)
        self.right_frame.pack(fill=tk.BOTH, expand=True)

        # Text area for module data interaction
        self.module_text_area = tk.Text(self.right_frame, wrap="word", height=30, width=40)
        self.module_text_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Button panel for module operations
        btn_frame = tk.Frame(self.right_frame)
        btn_frame.pack(pady=10)

        load_btn = tk.Button(btn_frame, text="Load Core Code", command=self.load_core_code)
        load_btn.grid(row=0, column=0, padx=5)

        save_core_btn = tk.Button(btn_frame, text="Save Core Code", command=self.save_core_code)
        save_core_btn.grid(row=0, column=1, padx=5)

        save_module_btn = tk.Button(btn_frame, text="Save Module", command=self.save_module)
        save_module_btn.grid(row=1, column=0, padx=5)

        integrate_btn = tk.Button(btn_frame, text="Integrate Module", command=self.integrate_module)
        integrate_btn.grid(row=1, column=1, padx=5)

        quit_btn = tk.Button(btn_frame, text="Quit", command=self.root.quit)
        quit_btn.grid(row=2, column=0, columnspan=2, pady=10)

        # Initialize the PanedWindow
        self.paned_window.add(self.left_frame)
        self.paned_window.add(self.right_frame)

        # Start the Tkinter event loop
        self.root.mainloop()

    def load_core_code(self):
        """
        Opens a file dialog to load code into the core manager and displays it in the GUI.
        """
        filepath = filedialog.askopenfilename(title="Select a code file", filetypes=[("Python Files", "*.py")])
        if filepath:
            filename = os.path.basename(filepath)
            try:
                with open(filepath, 'r') as file:
                    code = file.read()
                    self.core_manager.core_code = code  # Store the code in the core manager
                    
                    # Clear the text area before inserting new code
                    self.core_code_display.delete(1.0, tk.END)
                    
                    # Insert the loaded code into the text area
                    self.core_code_display.insert(tk.END, f"Loaded code from {filename}:\n\n")
                    self.core_code_display.insert(tk.END, code)  # Insert the actual code content
                    self.core_code_display.insert(tk.END, f"\n\n-- End of Loaded Code --\n\n")

            except Exception as e:
                print(f"Error loading file: {str(e)}")

    def save_core_code(self):
        """
        Saves the current core code displayed in the left pane as a Python file.
        """
        code_to_save = self.core_code_display.get(1.0, tk.END).strip()
        if not code_to_save:  # If there's no content in the text area
            print("No code to save.")
            return

        filepath = filedialog.asksaveasfilename(defaultextension=".py", filetypes=[("Python Files", "*.py")])
        if filepath:
            filename = os.path.basename(filepath)
            
            # Save the content from the text area to the file
            with open(filepath, 'w') as file:
                file.write(code_to_save)
            
            # Save as core code (not module)
            self.core_manager.save_core_code(code_to_save, filename)

    def save_module(self):
        """
        Saves the current module as a Python file in the module updates folder.
        """
        module_code = self.module_text_area.get(1.0, tk.END).strip()
        if module_code:
            filename = filedialog.asksaveasfilename(defaultextension=".py", filetypes=[("Python Files", "*.py")])
            if filename:
                self.core_manager.save_core_code(module_code, filename, is_module=True)
                print(f"Module saved as {filename}")

    def integrate_module(self):
        """
        Integrates a new module into the core code.
        """
        new_module = "print('New module integrated!')"
        updated_code = self.integrator.integrate_module(new_module, "new_module.py")
        print(f"Updated Core Code:\n{updated_code}")
        
        self.module_text_area.delete(1.0, tk.END)  # Clear the module text area after integration


# Run the application
if __name__ == "__main__":
    app = CodexNexusApp()
    app.initialize_ui()